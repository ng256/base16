﻿Base-16 Encoding Utility v. 1.3


The MIT License (MIT)
Copyright: © 2019-2021 NG256.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Usage: base16 [-e|-d] [-s] [-delimiter char] [-prefix prestr] [-postfix poststr]  [-header hstr] [-footer fstr] [-l] [-w width] [-sfx] [-c] [-cs] [-vb] [-o outfile] [-f] file1 [file2...] [-t text] [-i]

Program operation mode.

 -e                      Encode data. This is default choise.

 -d                      Decode data.


Parameters that are used only for encoding.

 -s|-space               Group bytes in the output with spaces.

 -delimiter {char}       Use the specified delimiter char instead spaces. Used only with the -s key.

 -prefix {string}        Use the specified prefix string for every byte. This parameter is sensitive to escape characters.

 -postfix {string}       Use the specified postfix string for every byte except the last item. This parameter is sensitive to escape characters.

 -header {string}        Use the specified header string before output data. This parameter is sensitive to escape characters.

 -footer {string}        Use the specified footer string after output data. This parameter is sensitive to escape characters.

 -l|-lcase               Convert output to lowercase.

 -w|-wrap {width}        Split the specified number of characters into lines. A value of this parameter less than 2 will be ignored. By default, the output will not wrap.

 -sfx                    Write a special command lines before the encoded data to create a self-extracting batch file. Items such as -s, -prefix, -postfix and -delimiter will be ignored.

 -c                      Create an array declaration for a C-like language. Items such as -s, -prefix, -postfix and -delimiter will be ignored.

 -cs                     Create an array declaration for a S-Sharp language. Items such as -s, -prefix, -postfix and -delimiter will be ignored.

 -vb                     Create an array declaration for a Visual Basic language. Items such as -s, -prefix, -postfix and -delimiter will be ignored.



Configuring input and output.

 -o|-output {outfile}    Set output to file {outfile}. If parameter is omitted, program's output will be redirected to the console window.

 {file1} {file2} ...     Input files containing data to be encoded.

 -f|-file {value as file name}        Force use value as input filename (to escape parameters). If input files is omitted, program's input will be redirected to the standard input. Instead of a file name, you can specify a directory and file mask to search for files. 

 -t|-text {text for encoding/decoding}        Use typed text value instead of input. This parameter is sensitive to escape characters and should be after all other parameters. 

 -i|-input				Read data from standard input device until Ctrl+C pressed. All listed files or key -t will be ignored.



Examples of using.

 base16 file1.txt
Will display the encoded data of file "file1.txt".

 base16 file1.txt -o file2.txt
Will save the encoded data from "file1.txt" to "file2.txt". 

 base16 -s file1.txt -o file2.txt
Will save data from file "file1.txt" to output "file2.txt", separated by bytes.

 base16 -s -t Foo
Will display: 46 6F 6F.

 base16 -s -prefix 0x -postfix , -t Bar
Will display: 0x42, 0x61, 0x72.

 base16 -t Hello, world
Will display: 48656C6C6F2C20776F726C64.

 base16 -i
Will input data from keyboard and encode it.

 base16 -d -t 42 61 72
Will display: Bar.

 base16 -s -w 16 -l -delimiter ; test.txt
Will display the encoded content of the file "test.txt" with a custom separator ";" between bytes and wrap to a lines width of 16.

 base16 -d encoded.txt -o original.txt
Will output the decoded content of the file "encoded.txt" to a new file "original.txt".

 base16 -c -t Hello, world
Will display:
unsigned char[]
{
0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x2C, 0x77, 0x6F, 0x72, 0x6C, 0x64
}

 base16 -sfx -t Hello, world
Output encoded text into self-extracting batch file on the screen.
The content on the screen of batch file looks like this:
____________________________________________________________________
  :BEGIN
  @ECHO OFF
  SET /P filename="Enter filename: "
  SET tmpfile=%~d0%~p0%RANDOM%.tmp
  SET outfile=%~d0%~p0%filename%
  ECHO tmpfile = %tmpfile%
  ECHO outfile = %outfile%
  FINDSTR "^[0-9A-F][0-9A-F][^\s]" %0 > "%tmpfile%"
  certutil -decodehex "%tmpfile%" "%outfile%"
  TIMEOUT 3
  DEL /F /Q "%tmpfile%" %0
  EXIT

48 65 6C 6C 6F 2C 20 77 6F 72 6C 64
____________________________________________________________________