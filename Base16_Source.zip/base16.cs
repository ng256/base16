﻿/************************************************************

Base-16 encoding utility v. 1.2

The MIT License (MIT)

Copyright (c) 2021 NG256

Permission is  hereby granted, free of charge, to any person
obtaining   a copy    of    this  software    and associated
documentation  files  (the "Software"),    to  deal   in the
Software without  restriction, including without  limitation
the rights to use, copy, modify, merge, publish, distribute,
sublicense,  and/or  sell  copies   of  the Software, and to
permit persons to whom the Software  is furnished to  do so,
subject       to         the      following      conditions:

The above copyright  notice and this permission notice shall
be  included  in all copies   or substantial portions of the
Software.

THE  SOFTWARE IS  PROVIDED  "AS IS", WITHOUT WARRANTY OF ANY
KIND, EXPRESS  OR IMPLIED, INCLUDING  BUT NOT LIMITED TO THE
WARRANTIES  OF MERCHANTABILITY, FITNESS    FOR A  PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN  NO EVENT SHALL  THE AUTHORS
OR  COPYRIGHT HOLDERS  BE  LIABLE FOR ANY CLAIM,  DAMAGES OR
OTHER LIABILITY,  WHETHER IN AN  ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF   OR IN CONNECTION  WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 

***********************************************************/

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using static System.Int32;
using static System.String;

namespace Base16
{
    public static class Program
    {
        #region Global Parameters

        private static readonly Encoding TextEncoding =
            Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage);

        private static readonly int ConsoleWidth = Console.WindowWidth;
        private static readonly string CommandLine = Environment.CommandLine;

        /* Self-extracting command lines.
          :BEGIN  
          @ECHO OFF  
          SET /P filename="Enter filename: "  
          SET tmpfile=%~d0%~p0%RANDOM%.tmp  
          SET outfile=%~d0%~p0%filename%  
          ECHO tmpfile = %tmpfile%  
          ECHO outfile = %outfile%  
          FINDSTR "^[0-9A-F][0-9A-F][^\s]" %0 > "%tmpfile%"  
          certutil -decodehex "%tmpfile%" "%outfile%"  
          TIMEOUT 3  
          DEL /F /Q "%tmpfile%" %0  
          EXIT  
        */
        private static readonly byte[] SfxString = 
        {
            0x20, 0x20, 0x3A, 0x42, 0x45, 0x47, 0x49, 0x4E, 0x0D, 0x0A, 0x20,
            0x20, 0x40, 0x45, 0x43, 0x48, 0x4F, 0x20, 0x4F, 0x46, 0x46, 0x0D,
            0x0A, 0x20, 0x20, 0x53, 0x45, 0x54, 0x20, 0x2F, 0x50, 0x20, 0x66,
            0x69, 0x6C, 0x65, 0x6E, 0x61, 0x6D, 0x65, 0x3D, 0x22, 0x45, 0x6E,
            0x74, 0x65, 0x72, 0x20, 0x66, 0x69, 0x6C, 0x65, 0x6E, 0x61, 0x6D,
            0x65, 0x3A, 0x20, 0x22, 0x0D, 0x0A, 0x20, 0x20, 0x53, 0x45, 0x54,
            0x20, 0x74, 0x6D, 0x70, 0x66, 0x69, 0x6C, 0x65, 0x3D, 0x25, 0x7E,
            0x64, 0x30, 0x25, 0x7E, 0x70, 0x30, 0x25, 0x52, 0x41, 0x4E, 0x44,
            0x4F, 0x4D, 0x25, 0x2E, 0x74, 0x6D, 0x70, 0x0D, 0x0A, 0x20, 0x20,
            0x53, 0x45, 0x54, 0x20, 0x6F, 0x75, 0x74, 0x66, 0x69, 0x6C, 0x65,
            0x3D, 0x25, 0x7E, 0x64, 0x30, 0x25, 0x7E, 0x70, 0x30, 0x25, 0x66,
            0x69, 0x6C, 0x65, 0x6E, 0x61, 0x6D, 0x65, 0x25, 0x0D, 0x0A, 0x20,
            0x20, 0x45, 0x43, 0x48, 0x4F, 0x20, 0x74, 0x6D, 0x70, 0x66, 0x69,
            0x6C, 0x65, 0x20, 0x3D, 0x20, 0x25, 0x74, 0x6D, 0x70, 0x66, 0x69,
            0x6C, 0x65, 0x25, 0x0D, 0x0A, 0x20, 0x20, 0x45, 0x43, 0x48, 0x4F,
            0x20, 0x6F, 0x75, 0x74, 0x66, 0x69, 0x6C, 0x65, 0x20, 0x3D, 0x20,
            0x25, 0x6F, 0x75, 0x74, 0x66, 0x69, 0x6C, 0x65, 0x25, 0x0D, 0x0A,
            0x20, 0x20, 0x46, 0x49, 0x4E, 0x44, 0x53, 0x54, 0x52, 0x20, 0x22,
            0x5E, 0x5B, 0x30, 0x2D, 0x39, 0x41, 0x2D, 0x46, 0x5D, 0x5B, 0x30,
            0x2D, 0x39, 0x41, 0x2D, 0x46, 0x5D, 0x5B, 0x5E, 0x5C, 0x73, 0x5D,
            0x22, 0x20, 0x25, 0x30, 0x20, 0x3E, 0x20, 0x22, 0x25, 0x74, 0x6D,
            0x70, 0x66, 0x69, 0x6C, 0x65, 0x25, 0x22, 0x0D, 0x0A, 0x20, 0x20,
            0x63, 0x65, 0x72, 0x74, 0x75, 0x74, 0x69, 0x6C, 0x20, 0x2D, 0x64,
            0x65, 0x63, 0x6F, 0x64, 0x65, 0x68, 0x65, 0x78, 0x20, 0x22, 0x25,
            0x74, 0x6D, 0x70, 0x66, 0x69, 0x6C, 0x65, 0x25, 0x22, 0x20, 0x22,
            0x25, 0x6F, 0x75, 0x74, 0x66, 0x69, 0x6C, 0x65, 0x25, 0x22, 0x0D,
            0x0A, 0x20, 0x20, 0x54, 0x49, 0x4D, 0x45, 0x4F, 0x55, 0x54, 0x20,
            0x33, 0x0D, 0x0A, 0x20, 0x20, 0x44, 0x45, 0x4C, 0x20, 0x2F, 0x46,
            0x20, 0x2F, 0x51, 0x20, 0x22, 0x25, 0x74, 0x6D, 0x70, 0x66, 0x69,
            0x6C, 0x65, 0x25, 0x22, 0x20, 0x25, 0x30, 0x0D, 0x0A, 0x20, 0x20,
            0x45, 0x58, 0x49, 0x54, 0x0D, 0x0A, 0x0D, 0x0A
        };

        private static bool _stdInput = false;      // Read data from standard input.
        private static bool _sfx = false;           // Create SFX batch file.
        private static bool _carr = false;          // Create C-like array declaration.
        private static bool _whiteSpace = false;    // Insert delimiters between bytes in output.
        private static bool _lcase = false;         // Convert output characters to lower case.
        private static char _dellimiter = ' ';      // Delimiter character.
        private static int _wrapWidth = MinValue;   // Wrap lines using current width.
        private static string _prefix = null;       // Prefix to every byte.
        private static string _postfix = null;      // Postfix for every byte except the last item.

        #endregion

        #region Encoding Stream Object

        // Represents stream that converts the original data to and from hexadecimal characters.
        private class HexEncodingStream : Stream
        {
            private readonly bool _leaveOpen = true;
            private int _linePosition = 0;
            private Stream _baseStream;
            private TextWriter _writer;
            private TextReader _reader;
            private int _itemLength;

            private HexEncodingStream() : base()
            {
                _itemLength = _whiteSpace ?  3 :  2;
                if (!IsNullOrEmpty(_prefix)) _itemLength += _prefix.Length;
                if (!IsNullOrEmpty(_postfix)) _itemLength += _postfix.Length;
            }

            public HexEncodingStream(Stream stream, bool leaveOpen = true) : this()
            {
                if (stream == null) throw new ArgumentNullException(nameof(stream));
                if (stream.CanRead) _reader = new StreamReader(stream);
                if (stream.CanWrite) _writer = new StreamWriter(stream);
                _baseStream = stream;
                _leaveOpen = leaveOpen;
            }

            public override void Flush()
            {
                _baseStream.Flush();
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                return _baseStream.Seek(offset, origin);
            }

            public override void SetLength(long value)
            {
                _baseStream.SetLength(value);
            }

            // [MethodImpl(MethodImplOptions.AggressiveInlining)] // Uncomment if necessary.
            private char GetHexChar(int h)
            {
                if (h < 10) return (char) (h + 0x30);
                return (char) (_lcase ?  h + 0x57 :  h + 0x37);
            }

            // [MethodImpl(MethodImplOptions.AggressiveInlining)] // Uncomment if necessary.
            private int ReadNextDigit()
            {
                int r;
                while ((r = _reader.Read()) >= 0)
                {
                    if (r > 0x2F && r < 0x3A) return r - 0x30;
                    if (r > 0x40 && r < 0x47) return r - 0x37;
                    if (r > 0x60 && r < 0x67) return r - 0x57;
                }

                return -1;
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                if (!CanRead) throw new NotSupportedException();
                int length = 0;
                for (int i = offset; i < offset + count; i++)
                {
                    int @byte = 0;
                    int digit = ReadNextDigit();
                    if (digit >= 0) @byte = digit << 4; else break;
                    digit = ReadNextDigit();
                    if (digit >= 0) @byte += digit; else break;
                    length++;
                    buffer[i] = unchecked((byte)@byte);
                }

                return length;
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                if (!CanWrite) throw new NotSupportedException();
                if (buffer == null) throw new ArgumentNullException(nameof(buffer));
                if (offset < 0) throw new ArgumentOutOfRangeException(nameof(buffer));
                if (count < 1) throw new ArgumentOutOfRangeException(nameof(buffer));

                int capacity = count * _itemLength;
                if (_wrapWidth > 2) capacity += capacity / _wrapWidth * 2;
                StringBuilder sb = new StringBuilder(capacity);
                for (int i = offset, limit = offset + count; i < limit; i++)
                {
                    byte b = buffer[i];

                    if (_prefix != null)
                    {
                        sb.Append(_prefix);
                        _linePosition += _prefix.Length;
                    }

                    sb.Append(GetHexChar(b / 16));
                    sb.Append(GetHexChar(b % 16));
                    _linePosition += 2;

                    if (i == limit - 1) break;

                    if (_postfix != null)
                    {
                        sb.Append(_postfix);
                        _linePosition += _postfix.Length;
                    }

                    if (_whiteSpace)
                    {
                        sb.Append(_dellimiter);
                        _linePosition++;
                    }

                    if (_wrapWidth > 2 && _linePosition >= _wrapWidth)
                    {
                        sb.Append("\r\n");
                        _linePosition = 0;
                    }
                }

                _writer.Write(sb.ToString());
            }

            public override bool CanRead => _baseStream.CanRead;

            public override bool CanSeek => _baseStream.CanSeek;

            public override bool CanWrite => _baseStream.CanWrite;

            public override long Length => _baseStream.Length;

            public override long Position
            {
                get => _baseStream.Position;
                set => _baseStream.Position = value;
            }

            protected override void Dispose(bool disposing)
            {
                _writer?.Flush();
                if (disposing && !_leaveOpen)
                {
                    _writer?.Close();
                    _reader?.Close();
                    _baseStream?.Close();
                }

                _writer = null;
                _reader = null;
                _baseStream = null;
            }
        }

        #endregion

        #region Enums

        private enum Mode : byte { Encode = 0, Decode = 1, Unspecified = 0xFF }
        private enum FileType { Unknown = 0, Disk = 1, Char = 2, Pipe = 3 } // "Pipe" if redirected std streams, "Char" otherwise.
        private enum StdHandle { StdIn = -10, StdOut = -11, StdErr = -12 } // Type of std stream.

        #endregion

        #region Win32 Imports

        [DllImport("kernel32.dll")]
        private static extern FileType GetFileType([In] IntPtr hdl);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetStdHandle([In] StdHandle std);

        [DllImport("kernel32.dll")]
        public static extern void ExitProcess([In] int exitCode);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        private static extern int GetModuleFileName([In] IntPtr hModule,
            [Out, MarshalAs(UnmanagedType.LPTStr)] string lpBuffer,
            [In, MarshalAs(UnmanagedType.I4)] int nSize);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        internal static extern int GetCurrentDirectory(
            [In, MarshalAs(UnmanagedType.I4)] int nSize,
            [Out, MarshalAs(UnmanagedType.LPTStr)] string lpBuffer);

        private static string GetModuleName()
        {
            string buffer = new string('\0', 260);
            int length = GetModuleFileName(IntPtr.Zero, buffer, 260);
            string moduleName = length > 0 
                ? Path.GetFullPath(buffer.Substring(0, length)) 
                : "base16.exe";
            return Path.GetFileNameWithoutExtension(moduleName).ToLowerInvariant();
        }

        private static string GetCurrentDirectory()
        {
            string buffer = new string('\0', 260);
            int length = GetCurrentDirectory(260, buffer);
            return length > 0 
                ? buffer.Substring(0, length) 
                : Path.GetDirectoryName(GetModuleName());
        }

        #endregion

        #region Additional Tools

        // Tries to perform the specified action or display an error message if it fails.
        private static bool TryAction(Action a, string message = null, int errorLevel = 0)
        {
            try
            {
                a?.Invoke();
                return true;
            }
            catch (Exception e)
            {
                using (StreamWriter errorWriter = new StreamWriter(Console.OpenStandardError(), TextEncoding))
                    errorWriter.WriteLine(WordWrap(IsNullOrEmpty(message)? e.Message : message, ConsoleWidth));
                if (errorLevel > 0) ExitProcess(errorLevel);
                return false;
            }
        }

        // Recursive file search.
        private static void SearchFiles(List<string> result, string directory)
        {
            string[] items = null;

            if (TryAction(() => items = Directory.GetFiles(directory)))
                result?.AddRange(items);

            if (TryAction(() => items = Directory.GetDirectories(directory)))
                foreach (string item in items)
                    SearchFiles(result, item);
        }

        // Searches for a file by mask.
        private static List<string> SearchFiles(string path)
        {
            List<string> result = new List<string>(255);
            if (Directory.Exists(path))
            {
                char last = path.Last();
                char altDirectorySeparatorChar = Path.AltDirectorySeparatorChar;
                char directorySeparatorChar = Path.DirectorySeparatorChar;
                if (last == altDirectorySeparatorChar)
                    path = path.Replace(altDirectorySeparatorChar, directorySeparatorChar);
                else if (last != directorySeparatorChar) path += directorySeparatorChar;
            }

            string searchPattern = Path.GetFileName(path);
            string directory = Path.GetDirectoryName(path);
            if (IsNullOrEmpty(directory)) directory = GetCurrentDirectory();
            if (IsNullOrEmpty(searchPattern)) SearchFiles(result, directory);
            else result.AddRange(Directory.GetFiles(directory, searchPattern));
            return result;
        }

        // Decodes hex dump to original data.
        private static void Decode(Stream input, Stream output)
        {
            using (Stream encodingStream = new HexEncodingStream(input, false))
                TryAction(() => encodingStream.CopyTo(output),
                    "Critical error: could not perform decoding! Exit process.", 1);
        }

        // Encodes input data to hex dump. 
        private static void Encode(Stream input, Stream output)
        {
            const string ERR_MSG = "Critical error: could not perform encoding! Exit process.";

            // Writes SFX command line header before data.
            if (_sfx)
                TryAction(() => output.Write(SfxString, 0, SfxString.Length), ERR_MSG, 1);

            // Writes "{" for array declaration.
            else if (_carr)
                TryAction(() => output.Write(new byte[] { 0x7B, 0x0D, 0x0A }, 0, 3), ERR_MSG, 1);

            // Encodes data.
            using (Stream encodingStream = new HexEncodingStream(output, true))
                TryAction(() => input?.CopyTo(encodingStream), ERR_MSG, 1);

            // Writes "}" for array declaration.
            if (_carr)
                TryAction(() => output.Write(new byte[] { 0x0D, 0x0A, 0x7D, 0x0D, 0x0A }, 0, 5), ERR_MSG, 1);
        }

        // This function wraps words. Using "_" means a non-breaking space in the text.
        private static string WordWrap(string text, int width) 
        {
            int pos, next;
            StringBuilder sb = new StringBuilder();

            if (width < 1)
                return text;

            for (pos = 0; pos < text.Length; pos = next)
            {
                int eol = text.IndexOf(Environment.NewLine, pos, StringComparison.Ordinal);
                if (eol == -1)
                    next = eol = text.Length;
                else
                    next = eol + Environment.NewLine.Length;

                if (eol > pos)
                {
                    do
                    {
                        int len = eol - pos;
                        if (len > width)
                            len = BreakLine(text, pos, width);
                        sb.Append(text, pos, len);
                        sb.Append(Environment.NewLine);

                        pos += len;
                        while (pos < eol && char.IsWhiteSpace(text[pos]))
                            pos++;
                    } while (eol > pos);
                }
                else sb.Append(Environment.NewLine);
            }

            // The underline will be replaced by non-breaking spaces between words, which will not be wrapped.
            return sb.Replace('_', ' ').ToString();
        }

        // [MethodImpl(MethodImplOptions.AggressiveInlining)] // Uncomment if necessary.
        private static int BreakLine(string text, int pos, int max)
        {
            int i = max;
            while (i >= 0 && !char.IsWhiteSpace(text[pos + i]))
                i--;

            if (i < 0)
                return max;

            while (i >= 0 && char.IsWhiteSpace(text[pos + i]))
                i--;

            return i + 1;
        }

        // [MethodImpl(MethodImplOptions.AggressiveInlining)] // Uncomment if necessary.
        static string PadRight(string s)
        {
            return s.PadRight(24, ' ');
        }

        // Displays a line that can be wrapped.
        static void WriteLine(string s = null) 
        {
            if (s == null) Console.WriteLine();
            else Console.WriteLine(WordWrap(s, ConsoleWidth));
        }

        // Displays a two-column table, the second column can be wrapped.
        static void WriteLine(string column1, string column2) 
        {
            Console.WriteLine(WordWrap(' ' + PadRight(column1) + column2, ConsoleWidth));
        }

        // Displays a center-aligned title.
        static void WriteTitle(string s)
        {
            int length = s.Length + 2;
            int padWidth = (ConsoleWidth > length + 2 ? ConsoleWidth - length : 2) / 2;
            string p = Empty.PadRight(padWidth, '-');

            WriteLine($"{p} {s} {p}");

        }

        #endregion

        #region Display Help

        static void WriteLittleHint()
        {
            WriteLine("There is no data for encode or decode. Exit process.\r\n"
                      + $"P.S. Type {GetModuleName()} without parameters to display help.");
            ExitProcess(1);
        }

        static void WriteFullHelp()
        {
            string moduleName = GetModuleName();
            Assembly assembly = Assembly.GetExecutingAssembly();
            AssemblyName assemblyName = assembly.GetName();
            string version = assemblyName.Version.ToString();
#if DEBUG
            version += " (debug)";
#endif
            WriteLine();
            WriteLine($" Base-16 Encoding Utility v. {version}.\r\n Copyright: (C) 2019-{DateTime.Today.Year} NG256.");
            WriteLine();

            WriteLine($" Usage: {moduleName} [-e|-d] [-s] [-delimiter_char] [-prefix_prefixstr] [-postfix_postfixstr] [-l] [-w_width] [-o_outfile] [-f]_file1_[file2...] [-t_text] [-i]");
            WriteLine();

            WriteTitle("Program operation mode");
            WriteLine("-e", "Encode data. This is default choise.");
            WriteLine("-d", "Decode data.");

            WriteTitle("Parameters that are used only for encoding");
            WriteLine("-s|-space", "Group bytes in the output with spaces.");
            WriteLine("-delimiter {char}", "Use the specified delimiter instead spaces. Used only with the_-s key.");
            WriteLine("-prefix {prefixstr}", "Use the specified prefix for every byte.");
            WriteLine("-postfix {postfixstr}", "Use the specified postfix for every byte except the last item.");
            WriteLine("-l|-lcase", "Convert output to lowercase.");
            WriteLine("-w|-wrap {width}", "Split the_specified number of characters into lines. " +
                                          "A_value of this parameter less than 2 will_be ignored. By default, the output will not wrap.");
            WriteLine("-sfx", "Write a_special command lines before the encoded data to create a_self-extracting batch file. " +
                              "Items such as -s, -prefix, -postfix and -delimiter will be ignored.");
            WriteLine("-c", "Create an array declaration for a_C-like language. " +
                                "Items such as -s, -prefix, -postfix and -delimiter will be ignored.");

            WriteTitle("Configuring input and output");
            WriteLine("-o|-output_{outfile}", "Set output to file {outfile}. " +
                                              "If parameter is_omitted, program's output will_be redirected to_the console window.");
            WriteLine("{file1}_{file2}_...", "Input files containing data to_be encoded.");
            WriteLine("-f|-file {value}", "Force use value as input filename (to escape parameters).");
            WriteLine(" If input files is omitted, program's input will be redirected to the standard input. " +
                      "Instead of a file name, you can specify a directory and file mask to search for files.");
            WriteLine("-t|-text {value}", "Use typed text value instead of input. This stuff should be after all other arguments.");
            WriteLine("-i|-input", "Read data from standard input device until Ctrl+C pressed. All listed files or key_-t will be ignored.");

            WriteTitle("Examples of using");
            WriteLine($"{moduleName} file1.txt", "\r\nWill display the encoded data of file1.txt.");
            WriteLine($"{moduleName} file1.txt -o file2.txt", "\r\nWill save the encoded data from file1.txt to file2.txt.");
            WriteLine($"{moduleName} -t Hello, world", "\r\nWill display: 48656C6C6F2C20776F726C64.");
            WriteLine($"{moduleName} -i", "\r\nWill input data from keyboard and encode it.");
            WriteLine($"{moduleName} -s file1.txt -o file2.txt", "\r\nWill save the encoded data from file1.txt to file2.txt, separated by bytes.");
            WriteLine($"{moduleName} -s -prefix 0x -postfix , -t Foo", "\r\nWill display: 0x42, 0x6F, 0x6F.");
            WriteLine($"{moduleName} -d -t 42 61 72", "\r\nWill display: Bar.");
            WriteLine($"{moduleName} -s -w 16 -l -delimiter ; test.txt",
                "\r\nWill display the encoded content of the file_\"test.txt\" with a_custom separator_\";\" " +
                "between bytes and wrap to a_lines width_of_16.");
            WriteLine($"{moduleName} -d encoded.txt -o original.txt",
                "\r\nOutput the decoded content of the file_\"encoded.txt\" to_a new file_\"original.txt\".");

            ExitProcess(0);
        }

        #endregion

        // Program entry point.
        public static int Main(string[] args)
        {

            #region Settings

            int argc = args.Length;
            string outFileName = null;
            List<string> fileList = new List<string>();
            StringBuilder textBuffer = new StringBuilder(1024);
            Mode mode = Mode.Unspecified;

            #endregion

            #region Command Line Args

            if (argc == 0) WriteFullHelp();

            for (int i = 0; i < argc; i++)
            {
                string arg = args[i];
                bool notLast = i < argc - 1;
                const string EN_DE_ERR =
                    "Critical error: incorrect combination of command line arguments: -e_and_-d cannot be together. Exit process.";
                const string SFX_C_ERR =
                    "Critical error: incorrect combination of command line arguments: -sfx_and_-c cannot be together. Exit process.";
                switch (arg.ToLowerInvariant().Replace('/', '-'))
                {
                    case "-?":
                    case "-h":
                    case "-help":
                        WriteFullHelp();
                        continue;
                    case "-i":
                    case "-input":
                        _stdInput = true;
                        continue;
                    case "-sfx":
                        TryAction(() => _sfx = !_carr ? true : throw new Exception(SFX_C_ERR),  errorLevel: 1);
                        continue;
                    case "-c":
                        TryAction(() => _carr = !_sfx ? true : throw new Exception(SFX_C_ERR), errorLevel: 1);
                        continue;
                    case "-e":
                    case "-encode":
                        TryAction(() => mode = mode == Mode.Decode ? throw new Exception(EN_DE_ERR) : Mode.Encode, errorLevel: 1);
                        continue;
                    case "-d":
                    case "-decode":
                        TryAction(() => mode = mode == Mode.Encode ? throw new Exception(EN_DE_ERR) : Mode.Decode, errorLevel: 1);
                        continue;
                    case "-prefix" when notLast:
                        _prefix = args[++i];
                        continue;
                    case "-postfix" when notLast:
                        _postfix = args[++i];
                        continue;
                    case "-delimiter" when notLast:
                        arg = args[++i];
                        TryAction(() =>
                        {
                            _dellimiter = arg[0];
                            if (arg.Length > 1)
                                WriteLine(
                                    $"It's too_long input line_\"{arg}\" for delimiter parameter. " +
                                    $"Only the_first character_\"{_dellimiter}\" will be used.");
                        }, "Wrong input line for delimiter parameter.");
                        goto case "-space";
                    case "-s":
                    case "-space":
                        _whiteSpace = true;
                        continue;
                    case "-l":
                    case "-lcase":
                        _lcase = true;
                        continue;
                    case "-w" when notLast:
                    case "-wrap" when notLast:
                        arg = args[++i];
                        if (!TryAction(() =>
                            {
                                _wrapWidth = Parse(arg, NumberStyles.Integer, CultureInfo.InvariantCulture);
                                if (_wrapWidth < 2) throw new ArgumentException(null, nameof(_wrapWidth));
                            },
                            $"Input string \"{arg}\" is not in_a_correct format for wrap width parameter.\r\nThe_default value will_be_used.")
                        )
                            _wrapWidth = MinValue;
                        continue;
                    case "-o" when notLast:
                    case "-out" when notLast:
                        arg = args[++i];
                        if (!TryAction(() =>
                            {
                                if (!IsNullOrEmpty(outFileName)) throw  new Exception();
                                outFileName = Path.GetFullPath(arg);
                            },
                            $"Bad output file name: {arg}. The_default output will_be_used."))
                            outFileName = null;
                        continue;
                    case "-t" when notLast:
                    case "-text" when notLast:
                        if (TryAction(() =>
                        {
                            int startPos = CommandLine.IndexOf(arg, StringComparison.Ordinal) + arg.Length + 1;
                            textBuffer.Append(CommandLine.Substring(startPos));
                        })) goto start;
                            break;
                    case "-f" when notLast:
                    case "-file" when notLast:
                        arg = args[++i];
                        goto default;
                    default:
                        TryAction(() =>
                        {
                            List<string> list = SearchFiles(arg);
                            if (list.Count == 0) throw new FileNotFoundException(null, arg);
                            fileList.AddRange(list);
                        }, $"Could not find the specified path: {arg}. This item will be skipped.");
                        continue;
                }
            }

            #endregion

            #region Encoding/Decoding

            start:

            // Reads data from standard input until Ctrl+C pressed.
            TryAction(() =>
            {
                if (_stdInput)
                {
                    if (textBuffer.Length > 0) textBuffer.Clear();
                    using (TextWriter writer = new StreamWriter(Console.OpenStandardError(), TextEncoding))
                    {
                        Thread readKey = new Thread(() =>
                        {
                            writer.Write("Enter your text then press Ctrl+C to complete input:\r\n");
                            writer.Flush();
                            while (true)
                            {
                                ConsoleKeyInfo c = Console.ReadKey(true);
                                char keyChar = c.KeyChar;
                                if (keyChar == (char)8) keyChar = '\0';
                                switch (c.Key)
                                {
                                    case ConsoleKey.Enter:
                                        textBuffer.Append("\r\n");
                                        writer.WriteLine();
                                        writer.Flush();
                                        continue;
                                    case ConsoleKey.Backspace when Console.CursorLeft > 0 && textBuffer.Length > 0:
                                        textBuffer.Remove(textBuffer.Length - 1, 1);
                                        Console.CursorLeft--;
                                        writer.Write('\0');
                                        writer.Flush();
                                        Console.CursorLeft--;
                                        continue;
                                    default:
                                        if (keyChar == '\0')
                                            Console.Beep();
                                        else
                                        {
                                            textBuffer.Append(keyChar);
                                            writer.Write(keyChar);
                                            writer.Flush();
                                        }

                                        break;
                                }
                            }
                        });
                        ConsoleCancelEventHandler eventHandler = (sender, eventArgs) =>
                        {
                            eventArgs.Cancel = true;
                            readKey.Abort();
                        };
                        Console.CancelKeyPress += eventHandler;
                        readKey.Start();
                        while (readKey.IsAlive) Thread.Sleep(10);
                        if (textBuffer.Length > 0) writer.WriteLine();
                        Console.CancelKeyPress -= eventHandler;
                    }
                }
            }, "Critical error: could not open input device! Exit process.", 1);

            // Performs encoding or decoding.
            TryAction(() =>
            {
                using (Stream outStream = IsNullOrEmpty(outFileName)
                    ? Console.OpenStandardOutput()
                    : File.Create(outFileName, 4096, FileOptions.SequentialScan))
                    switch (mode)
                    {
                        case Mode.Encode:
                        case Mode.Unspecified:

                            // Configures the output for SFX HEX dump.
                            if (_sfx)
                            {
                                _whiteSpace = true;
                                _prefix = null;
                                _postfix = null;
                                _dellimiter = ' ';
                                _wrapWidth = _wrapWidth < 2 ? 64 : _wrapWidth;
                            }

                            // Configures the output for C-like array declaration.
                            else if (_carr)
                            {
                                _whiteSpace = true;
                                _prefix = "0x";
                                _postfix = ",";
                                _dellimiter = ' ';
                                _wrapWidth = _wrapWidth < 2 ? 64 : _wrapWidth;
                            }

                            // Encodes the text entered on the command line after argument -t.
                            if (textBuffer.Length > 0)
                                TryAction(() => Encode(new MemoryStream(TextEncoding.GetBytes(textBuffer.ToString())),
                                    outStream));

                            // Encodes files from a file list.
                            else if (fileList.Count > 0)
                                foreach (string fileName in fileList.Distinct())
                                    TryAction(() => Encode(File.OpenRead(fileName), outStream),
                                        $"Critical error: could not open input file: {fileName}", 1);

                            // Encodes standard input.
                            else if (GetFileType(GetStdHandle(StdHandle.StdIn)) != FileType.Char)
                                TryAction(() => Encode(Console.OpenStandardInput(), outStream),
                                    "Critical error: could not open standard input device! Exit process.", 1);

                            // If nothig have to do.
                            else WriteLittleHint();

                            break;

                        case Mode.Decode:

                            if (textBuffer.Length > 0)
                                TryAction(() => Decode(new MemoryStream(TextEncoding.GetBytes(textBuffer.ToString())),
                                    outStream));

                            else if (fileList.Count > 0)
                                foreach (string fileName in fileList.Distinct())
                                    TryAction(() => Decode(File.OpenRead(fileName), outStream),
                                        $"Critical error: could not open input file: {fileName}! Exit process.", 1);

                            else if (GetFileType(GetStdHandle(StdHandle.StdIn)) != FileType.Char)
                                TryAction(() => Decode(Console.OpenStandardInput(), outStream),
                                    "Critical error: could not open standard input device! Exit process.", 1);

                            else WriteLittleHint();

                            break;
                    }
            }, "Critical error: could not open output device! Exit process.", 1);

            #endregion

#if DEBUG
            TryAction(() => throw new Exception("\r\nPress any key to end debugging..."));
            Console.ReadKey(true);
#endif

            return 0;
        }
    }
}